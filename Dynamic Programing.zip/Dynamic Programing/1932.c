#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
int dp[501][501];
int sq[501][501];

//정수삼각형
int max1(int a,int b){
    if(a<b){return b;}
    else{return a;}
}

int main(void){
    int n=0;
    scanf("%d",&n);
    
    for(int i=0;i<n;i++){
        for(int j=0;j<=i;j++){
            scanf("%d",&sq[i][j]);
        }
    }

    //dp[][]채우기~
    dp[0][0]=sq[0][0];
    int sum=dp[0][0];
    for(int i=1;i<n;i++){
        for(int j=0;j<=i;j++){//i=1 j=0,1
            sum=dp[i-1][j]+sq[i][j];
            //1,1 0,0 + 1,0
            if(sum>dp[i][j]){dp[i][j]=sum;}
            dp[i][j+1]=dp[i-1][j]+sq[i][j+1];
        }
    }
    
    int M=0;
    for(int i=0;i<n;i++){
        if(M<dp[n-1][i]){M=dp[n-1][i];}
    }
    printf("%d",M);
    return 0;
}
    
