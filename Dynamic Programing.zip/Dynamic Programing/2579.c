#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
//계단오르기 최대값

// 계단은 한 번에 한 계단씩 또는 두 계단씩 오를 수 있다. 즉, 한 계단을 밟으면서 이어서 다음 계단이나, 다음 다음 계단으로 오를 수 있다.
// 연속된 세 개의 계단을 모두 밟아서는 안 된다. 단, 시작점은 계단에 포함되지 않는다.
// 마지막 도착 계단은 반드시 밟아야 한다.
int max(int a,int b){
    if(a<b){return b;}
    else{ return a;}
}

int main(void){
    int n=0;
    scanf("%d",&n);
    int st[300];
    int dp[300];
    
    for(int i=0;i<n;i++){
        scanf("%d",&st[i]);
    }
    //1. 한칸을 뛰면 그다음은 무조건 두칸이 나온다 -첫번째는 예외
    //2. 몇칸인지는 +1 해서 더한 값들이 n과 같으면 종료?
    dp[0]=st[0];
    dp[1]=st[0]+st[1];
    dp[2]=max(st[1],st[0])+st[2];
    //2칸 3칸으로 쪼개서 생각
    for(int i=3;i<n;i++){
        dp[i]=max(dp[i-2],dp[i-3]+st[i-1])+st[i];
        
    }
    printf("%d",dp[n-1]);
    
    return 0;
}
    