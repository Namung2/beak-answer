#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
//입력창
int n=0;
int S[20][20];

//팀들
int start1[20];
int link[20];

//방문 여부
int vst[21];

//차의 최솟값
int min=200;

void start_link(){//이제 표에 나오는 Sij 의 값들을 합으로 더해주자
    int start_sum=0;
    int link_sum=0;
   for(int i=0;i<n/2;i++)
   {
       for(int j=0;j<n;j++){
           if(vst[j+1]&&start1[i]-1!=j){start_sum+=S[start1[i]-1][j];}
           if(!vst[j+1]&&start1[i]-1!=j){link_sum+=S[link[i]-1][j];}
       }
   }
    if(min>abs(start_sum-link_sum)){min=abs(start_sum-link_sum);}
}

// 팁 조합을 나누기
void each_level(int depth,int start){
    if(depth==n/2)//왜 n/2까지인가? 멤버는 n/2번멤버수만 하면 댄다
    {
        int j=0;
        for(int i=1;i<=n;i++){
            if(vst[i]){continue;}//vst[i]==1이면 start팀 멤버다..
            link[j++]=i;//아 나무지 멤버를 link배열에 넣어주면대지요
        }
        start_link();//팀을 다 나눈상태이므로 표에 적인 Sij의 합을 구하는 단계로..
        return;
    }
    else{
        for(int i=start;i<=n;i++){//이게 왜 start부터냐? 그전멤버인 i는 이미 끝난 멤버 다음 멤버인 i_1부터 찾으면 댐
            if(!vst[i]){//방문을 안했음면 방문을 해보리는거야
                start1[depth]=i;//재귀 깊이가 깊어질수록 멤버는 정해지는것
                vst[i]=1;//방문했다하고
                each_level(depth+1,i+1);//다음 멤버추가 언제까지? n/2번 즉 start 멤버 다 뽑을때까지
                vst[i]=0;
            }
        }
    }   
   
}



int main(void){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&S[i][j]);
        }
    }
    
    each_level(0,1);//0qjsqnxj
    printf("%d",min);
    
    return 0;
}
