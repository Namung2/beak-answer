#include <stdio.h>
//포도주 마실수있는 최대값 계산

// 포도주 잔을 선택하면 그 잔에 들어있는 포도주는 모두 마셔야 하고, 마신 후에는 원래 위치에 다시 놓아야 한다.
// 연속으로 놓여 있는 3잔을 모두 마실 수는 없다.
int max(int a,int b){
    if(a<b){return b;}
    else{return a;}
}

int main(void){
    int n=0;
    scanf("%d",&n);
    int wine_in[n+1];
    
    for(int i=1;i<=n;i++){
        scanf("%d",&wine_in[i]);
    }
    
    int dp[n+1];//index 까지의 최댓값이 dp[index]
    
    dp[1]=wine_in[1];
    dp[2]=wine_in[1]+wine_in[2];
    dp[3]=max(max(wine_in[1]+wine_in[2],wine_in[1]+wine_in[3]),wine_in[2]+wine_in[3]);
    
    for(int i=4;i<=n;i++){
        if(wine_in[i]!=0){//0이면 이전 dp을 그대로 유지
            dp[i]=max(max(dp[i-3]+wine_in[i-1]+wine_in[i],dp[i-2]+wine_in[i]),dp[i-1]);
        }//단순히 하나뒤,둘뒤의 요소를 더한값을 비교하는것이아니라 
        //원래코드 : dp[i]=max(dp[i-1]+wine_in[i],dp[i-2]+wine_in[i]);
        //경우에 따라 무엇이 큰지..
        //세칸 뒤 지점부터 요소들을 더한값 dp[i-3]+wine_in[i-1]+wine_in[i]
        //두칸 뒤 지점부터 요소를 더한값 dp[i-2]+wine_in[i]
        //한칸 전 값 dp[i-1] 이경우 요소를 선택하지않고 다음을 보는것
        //이셋중에 합이 가장 큰 경우의 수를 구하는것 
        else{dp[i]=dp[i-1];}//0이라면 당연히 이전의 값을 이어받음 선택하지 않든 선택하든
    }
    
    printf("%d",dp[n]);
   
    return 0;
}
