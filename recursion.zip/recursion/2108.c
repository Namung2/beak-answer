#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//핵심은 최빈값
int arithmeticMean(int *numList,int N){
    
    double sum=0.0;
    for(int i=0;i<N;i++){
        sum+=numList[i];
    }
    return (int)round(sum/N);
}

int *compare(const int *f,const int *s){
    return (*f-*s);
}

int median(int numList[],int N){
    //sort
    qsort(numList,N,sizeof(int),compare);
    return numList[N/2];
}

int mostFrequent(int *numList,int N){
    int countLinst[8001];//분산이 너무되있는데 해야하나.. 8000이면 할만 한것같은데 ㅋㅋ
    //중복제거? counting? 
    for(int i=0;i<8001;i++){countLinst[i]=0;}
    for(int i=0;i<N;i++){
        countLinst[numList[i]+4000]++;
    }
    
    int Max_f=0;
    int c=0;
    int res=0;
    for(int i=0;i<8001;i++){
        //if(c>1){break;}
        if(Max_f<countLinst[i]){c=1;Max_f=countLinst[i];res=i-4000;}
        else{
            if(Max_f==countLinst[i]){
                if(c==1){c++;res=i-4000;}
                else {c++;}
                
            }
        }
    }
    
    return res;
}
int Max_min(int numList[],int N){//1,2,2,3
    int Max=numList[0];
    int min=numList[0];
    for(int i=0;i<N;i++){
        if(Max<numList[i]){Max=numList[i];}
        if(min>numList[i]){min=numList[i];}
    }
    
    return Max-min;
}

int main(void){
    int N=0;
    scanf("%d",&N);
    int *numList=malloc(sizeof(int)*N);
    
    for(int i=0;i<N;i++){
        scanf("%d",&numList[i]);
    }
    printf("%d\n",arithmeticMean(numList,N));
    printf("%d\n",median(numList,N));
    printf("%d\n",mostFrequent(numList,N));
    printf("%d\n",Max_min(numList,N));
    
    return 0;
}