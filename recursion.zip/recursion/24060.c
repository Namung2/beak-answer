#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int c=0;
//이거 포인터로도 풀어보자
void merge(int *a,int p,int q,int r,int k,int *p1){
    int tmp[500005];
    int i=p;
    int j=q+1;
    int t=p;
    while(i<=q&&j<=r){
        if(a[i]<=a[j]){tmp[t++]=a[i++];}
        else{tmp[t++]=a[j++];}
    }
    
    while(i<=q){tmp[t++]=a[i++];}
    while(j<=r){tmp[t++]=a[j++];}
    
    for(i=p;i<=r;i++){
        a[i]=tmp[i];
        if(++c==k){*p1=a[i];break;}
    }
}

void merge_sort(int *a,int  p,int r,int k,int *p1){
    if(p<r){
        int q=(p+r)/2;
        merge_sort(a,p,q,k,p1);
        merge_sort(a,q+1,r,k,p1);
        merge(a,p,q,r,k,p1);
    }
}
int main(void){
    int n=0,k=0,ans=0;
    scanf("%d %d",&n,&k);
    int a[500005];
    for(int i=0;i<n;i++){scanf("%d",&a[i]);}
    merge_sort(a,0,n-1,k,&ans);
    if(c<k){printf("-1\n");}
    else printf("%d\n",ans);
    
    return 0;
}
