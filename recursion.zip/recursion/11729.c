#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int c=0;
void move(int n,int from, int tmp,int to){
    if(n==1){//무조건 하나는 최종to로 이동
        printf("%d %d\n",from,to);
    }
    else{
        move(n-1,from,to,tmp);//to를tmp로 사용하여 임시의 막대에 원판을 모두 옮김
        printf("%d %d\n",from,to);
        move(n-1,tmp,from,to);//tmp에서 출발 from를거쳐 to으로 도착 
    }
}
void move1(int n,int from, int tmp,int to){ c++;
   
    if(n==1){}
    else{
        move1(n-1,from,to,tmp);
        
        move1(n-1,tmp,from,to);}
}
int main(void){
    int n=0;
    scanf("%d",&n);
    int k=n;
    move1(k,1,2,3);
    printf("%d\n",c);
    move(n,1,2,3);
    
    
    return 0;
}
