#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int square(int n){
    int res=1;
    for(int i=0;i<n;i++){
        res=res*3;
    }
    return res;
}

void process(int res){
    //int i=0;
    if(res==1){
        printf("-");
        return 0;
    }
    if(res!=1){process(res/3);}
    for(int i=0;i<res/3;i++){printf(" ");}
    if(res!=1){process(res/3);}
}

int main(void){
    int n=0;
    while(scanf("%d",&n)==1){
    int res=square(n);
    process(res);
    printf("\n");
    }
    return 0;
}

    //process(str,index);
    // int index0=index/3; //3
    // cut(str,index0,index0);
    // cut(str,index*2+index0,index0);
    
    // int index1=index0/3; //1
    // cut(str,index1,index1);
    // cut(str,index0*2+index1,index1);
    // cut(str,index*2+index1,index1);
    // cut(str,index*2+index0*2+index1,index1);