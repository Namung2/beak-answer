#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
int num[21][21][21];

// int w1(int a,int b,int c){
//     if(a<=0||b<=0||c<=0){return 1;}
//     if(a>20||b>20||c>20){return w(20,20,20);}
//     if(a<b&&b<c){return w(a,b,c-1)+w(a,b-1,c-1)-w(a,b-1,c);}
    
//     return w(a-1,b,c)+w(a-1,b-1,c)+w(a-1,b,c-1)-w(a-1,b-1,c-1);
    
// }

//다이나믹 프로그래밍은 1. 중복되는 연산이 있는지 판단/2. 고려해야할 경우의수가 압도적으로 많을때
// 이전 연간값을 메모리에 저장하여 다음연산의 재료로 사용하는것
//그냥 게산값을 해당 배열에 저장하여 다음 재귀시 사용하면 가능

// w(a, b, c)를 dp에 넣어서 dp[a][b][c]가 이미 있는 값이면 반환해야 한다.
// 여기서 a나 b, c 중 하나라도 0이하의 수가 있으면 index관련한 오류가 뜰 것이다.
// 따라서 w함수에서 a,b,c중 음수가 있는지 먼저 판별한 후에 dp를 읽는다.
// 그것만 주의하면 어려울점은 없을 것 같다.
int w(int a,int b,int c){
    if(a<=0 || b<=0 || c<=0)
    {return 1;}
    if(a>20 || b>20 || c>20)
    {
        return w(20,20,20);
    }
    if(num[a][b][c]!=0){return num[a][b][c];}
    
    if(a<b && b<c){
        //a,b,c 모두 20이하
        return num[a][b][c]=w(a,b,c-1)+w(a,b-1,c-1)-w(a,b-1,c);
    }
    
    return num[a][b][c]=w(a-1,b,c)+w(a-1,b-1,c)+w(a-1,b,c-1)-w(a-1,b-1,c-1);
}
int main(void){
    int a=0,b=0,c=0;
    while(1){
        scanf("%d %d %d",&a,&b,&c);
        if(a==-1&& b==-1 &&c==-1){exit(0);}
        printf("w(%d, %d, %d) = %d\n",a,b,c,w(a,b,c));
    }
    
    

    return 0;
}
