#include <stdio.h>
#define mod 1000000000;


int main(void){
    int n=0;
    scanf("%d",&n);
    //dp에 저장되는건 index까지의 연산의 최솟값
    // 다음 연산 결과에 영향을 주는것 == dp == 연속된 연산
    int dp[101][11];
    //점화식? 이있나..
    
    for(int i=0;i<10;i++){dp[1][i]=1;}
    
    for(int i=2;i<n+1;i++){//자리수
        
        for(int j=0;j<10;j++){//현재 자리의 숫자
            if(j==0){//현재 0이면 이전엔 무조건 1이 있다는 뜻 그까지의 경우를 이어받음
                dp[i][j]=dp[i-1][1]%mod;
            }
            else if(j==9){
                dp[i][j]=dp[i-1][8]%mod;
            }
            else {
                dp[i][j]=(dp[i-1][j-1]+dp[i-1][j+1])%mod;
            }//+1 -1 까지의 경우의수를 더함
        }
        
        
    }
    int sum=0;//꼭 초기화하자
    for(int i=1;i<10;i++){
        sum=(sum+dp[n][i])%mod;
    }
    printf("%d",sum);
    
   
    return 0;
}