#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void process(int n,int m,int *chk,int depth,int *res){
   if(depth==m){
        for(int i=0;i<m;i++){//res값을 m길이만큼 출력
            printf("%d ",res[i]);
        }
       printf("\n");
    }
    else
    {
        for(int i=1;i<=n;i++){
            if(chk[i]==0)//체크가 안되있다면
            {
                res[depth]=i;//결과 수열에 출력할 값 추가 depth를 index로
                chk[i]=1;//방문체크표시
                process(n,m,chk,depth+1,res);//DFS탐색 depth를 m 까지 도달해야지만 res값에 m만큼의결과 출력할수있음,
                //왜 depth++를사용하면 안되지?
                //다음 재귀호출시 이미증가된depth값이 되버리기때문에 현재깊이+1이 재귀를 반복할때 맞는 코드
                //다음 깊이의 tree에 접근하기위해 depth+1;
                chk[i]=0;//없다면 다시 체크 해제
            }
        }
    }
    
}

int main(void){
    int n,m;
    scanf("%d %d",&n,&m);
    int *res=malloc(sizeof(int)*m);
    int *chk=malloc(sizeof(int)*(n+1));
    process(n,m,chk,0,res);//depth는 0부터
    
    return 0;
}
