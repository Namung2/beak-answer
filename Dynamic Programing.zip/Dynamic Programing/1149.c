#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
int color[1001][3];
int dp[1001][3];
int sum[3];
int n=0;
//RGB거리
int min1(int a,int b){
    if(a<b){return a;}
    return b;
}



int main(void){
    
    scanf("%d",&n);
    int color[1001][3];
    int dp[1001][3];
    int sum[3];
    
    for(int i=0;i<n;i++){
        for(int j=0;j<3;j++){
            scanf("%d",&color[i][j]);
        }
    }
    //최소값만 찾는다고 되는게 아니였누..!
    dp[0][0]=color[0][0];
    dp[0][1]=color[0][1];
    dp[0][2]=color[0][2];
    
    for(int i=0;i<n;i++){
        dp[i+1][0]=min1(dp[i][1],dp[i][2])+color[i+1][0];
        dp[i+1][1]=min1(dp[i][0],dp[i][2])+color[i+1][1];
        dp[i+1][2]=min1(dp[i][0],dp[i][1])+color[i+1][2];
    }
    
    
    int min=1000001;//1000이 1000번 나올수도 있다
    for(int i=0;i<3;i++){
        if(dp[n][i]<min){min=dp[n][i];}
    }
    printf("%d",min);

    return 0;
}