#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
//1로 만들기 

// X가 3으로 나누어 떨어지면, 3으로 나눈다.
// X가 2로 나누어 떨어지면, 2로 나눈다.
// 1을 뺀다.
int min(int a,int b){
    if(a<b){return a;}
    else{return b;}
}

int main(void){
    int n=0;
    scanf("%d",&n);
    
    //dp에 저장되는건 index까지의 연산의 최솟값
    // 다음 연산 결과에 영향을 주는것 == dp == 연속된 연산
    int dp[n+1];
    //점화식이 중요하네..머리를 좀더 써보자
    dp[1]=0;
    dp[2]=1;
    dp[3]=1;
    
    // dp[5]=dp[i-1]+1;
    
    // dp[6]=2 //6->2->1 2
    // dp[9]=2 //9->3->1 2
    // dp[12]=3 //12->4->2->1
    
    for(int i=4;i<=n;i++){
        dp[i]=dp[i-1]+1;
        if(i%3==0){dp[i]=min(dp[i],dp[i/3]+1);}
        if(i%2==0){dp[i]=min(dp[i],dp[i/2]+1);} 
    }
        
        
    
    printf("%d",dp[n]);
    return 0;
}