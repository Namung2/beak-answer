#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
typedef struct words{
    char word[11];
    int freq;
    int len;
}WORD;
//연결리스트? 시간이 오래걸릴듯 탐색후 재생성?
int compare(WORD* a, WORD* b, int flag) {//내림차순
	int i = 0;
	if (flag) {
		if (a->len > b->len) return 1;
		else if (a->len < b->len) return 0;
		//if(a->len==b->len) 부분
		while (a->word[i]) {//strcmp대신 사용 같은 글자인지
			if (a->word[i] < b->word[i]) return 1;
			else if (a->word[i] > b->word[i]) return 0;
			i++;
		}
		return 1;//같은글자면 넘어가 같은글자면 일단 넣어
	}
	if (a->freq >= b->freq) return 1;
	return 0;
}

void merge_sort(WORD a[], WORD sorted[], int l, int mid, int r, int flag) {
    int i = l;
	int j = mid + 1;
	int k = l;

	while (i <= mid && j <= r) {
		if (compare(&a[i], &a[j], flag)) {
			sorted[k] = a[i];
			i++;
		}
		else {
			sorted[k] = a[j];
			j++;
		}
		k++;
	}

	if (i > mid) {//l이 졌다
		for (int t = j; t <= r; t++) {
			sorted[k] = a[t];
			k++;
		}
	}
	else {//r이 졌다
		for (int t = i; t <= mid; t++) {
			sorted[k] = a[t];
			k++;
		}
	}
    //작성
	for (int t = l; t <= r; t++) {
		a[t] = sorted[t];
	}
	return;

}
void merge(WORD a[], WORD sorted[], int l, int r, int flag) {
	if (l < r) {
		int mid = (l+r) / 2;
		merge(a, sorted, l, mid, flag); //왼쪽파트
		merge(a, sorted, mid + 1, r, flag);//오른쪽파트
        
		merge_sort(a, sorted, l, mid, r, flag);
	}
	return;
}

int main(void){
    int N,M,k=0;
    scanf("%d %d",&N,&M);
    char buf[11];
    WORD *sorted=malloc(sizeof(WORD)*N);
    WORD *tmpwList=malloc(sizeof(WORD)*N);
    
    for(int i=0;i<N;i++){
        scanf("%s",buf);
        int wlen=strlen(buf);
        if(wlen>=M){
            strcpy(tmpwList[k].word,buf);
            tmpwList[k].len=wlen;
            tmpwList[k].freq=1;
            sorted[k]=tmpwList[k];
            k++;
        }
    }
    
    merge(tmpwList,sorted,0,N-1,1);
   
    int in=0,nein=1,sortk=0;
    while(in<k){
        if(strcmp(sorted[in].word,sorted[nein].word)){
            tmpwList[sortk++]=sorted[in];
            in=nein;
            nein=in+1;
            continue;
        }
        else {
            sorted[in].freq++;
        }
        nein++;
    }
    
    merge(tmpwList,sorted,0,sortk-1,0);//중복제거한뒤 빈도순으로 정렬
    
    for (int i = 0; i < sortk; i++) {
		printf("%s\n", tmpwList[i].word);
	}
    free(tmpwList);
    free(sorted);
    return 0;
}
