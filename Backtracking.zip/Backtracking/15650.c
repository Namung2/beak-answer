#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//오름차순을 판단하는 방법 

void process(int n,int m,int *chk,int depth,int *res){
   if(depth==m){
        for(int i=0;i<m;i++){//res값을 m길이만큼 출력
            printf("%d ",res[i]);}
       printf("\n");
    }
    else
    {
        for(int i=1;i<=n;i++){
            if(chk[i]==0)//체크가 안되있다면
            {
                
                res[depth]=i;//결과 수열에 출력할 값 추가 depth를 index로
                if(res[depth-1]<res[depth]){
                chk[i]=1;//방문체크표시
                process(n,m,chk,depth+1,res);
                
               //DFS탐색 depth를 m 까지 도달해야지만 res값에 m만큼의결과 출력할수있음,
                
                chk[i]=0;}
                //없다면 다시 체크 해제
            }
        }
    }
    
}

int main(void){
    int n,m;
    scanf("%d %d",&n,&m);
    int *res=malloc(sizeof(int)*m);
    int *chk=malloc(sizeof(int)*(n+1));
    process(n,m,chk,0,res);//depth는 0부터
    
    return 0;
}
